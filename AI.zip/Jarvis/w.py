import webbrowser

websites = {
    "google": "https://google.com",
    "youtube": "https://youtube.com",
    "facebook": "https://facebook.com",
    "wikipedia": "https://wikipedia.com",
    "instagram": "https://instagram.com",
    "twitter": "https://twitter.com",
    "linkedin": "https://linkedin.com",
    "reddit": "https://reddit.com",
    "amazon": "https://amazon.com",
    "netflix": "https://netflix.com",
    "github": "https://github.com",
    "stackoverflow": "https://stackoverflow.com",
    "bing": "https://bing.com",
    "yahoo": "https://yahoo.com",
    "TMU Portal": "https://portal.tmu.ac.in/"
}

def openWebsite(command):
    for site in websites:
        if f"open {site}" in command.lower():
            webbrowser.open(websites[site])
            return True
    return False

import webbrowser

#* GOOGLE SEARCH FUNCTION
def googleSearch(command):
    query = command.lower().replace("search google for", "").strip()
    url = f"https://www.google.com/search?q={query}"
    webbrowser.open(url)

