import pygame
import os
import random

def get_random_song(folder_path):
    
    files = [f for f in os.listdir(folder_path) if f.endswith('.mp3')]  # List all files in the folder
    if not files:
        raise ValueError("No MP3 files found in the folder")
    
    return os.path.join(folder_path, random.choice(files))  # Choose a random file

def play_song(file_path):
    pygame.mixer.init()  # Initialize the mixer
    pygame.mixer.music.load(file_path)  # Load the song
    pygame.mixer.music.play()  # Play the song
    while pygame.mixer.music.get_busy():  # Keep the program running while the song plays
        pygame.time.Clock().tick(10)

if __name__ == "__main__":
    
    folder_path = r"C:\Users\g k\Music" # Folder path where your MP3 files are located
    file_path = get_random_song(folder_path)    # Get a random song from the folder

    play_song(file_path)
