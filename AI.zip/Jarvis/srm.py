import psutil
#import pyttsx3

def check_system_status():
    battery = psutil.sensors_battery()
    cpu_usage = psutil.cpu_percent(interval=1)
    ram_usage = psutil.virtual_memory().percent

    status = f"CPU Usage: {cpu_usage} percent. RAM Usage: {ram_usage} percent."
    
    if battery:
        status += f" Battery: {battery.percent} percent."
    
    #speak(status)
    print(status)
