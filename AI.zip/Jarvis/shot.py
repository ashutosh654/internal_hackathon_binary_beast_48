import pyautogui
import time

def take_screenshot():
    """Captures and saves a screenshot with a timestamp."""
    timestamp = time.strftime("%Y-%m-%d_%H-%M-%S") 
    screenshot = pyautogui.screenshot()
    filename = f"screenshot_{timestamp}.png"
    screenshot.save(filename)
    print(f"Screenshot saved as {filename}")  
