import screen_brightness_control as sbc
import pyttsx3

engine = pyttsx3.init()

def speak(text):
    """Converts text to speech"""
    engine.say(text)
    engine.runAndWait()

def get_current_brightness():
    """Gets the current brightness level as an integer"""
    try:
        brightness = sbc.get_brightness(display=0)
        return brightness[0] if isinstance(brightness, list) else brightness
    except Exception as e:
        speak("Unable to fetch brightness level")
        print(f"Brightness Error: {e}")
        return None

def set_brightness(level):
    """Sets brightness to a specific level"""
    try:
        sbc.set_brightness(level, display=0)
        speak(f"Brightness set to {level} percent")
    
    except Exception as e:
        speak("An error occurred while setting brightness")
        print(f"Brightness Error: {e}")
