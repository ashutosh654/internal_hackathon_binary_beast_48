
#* LIBRARIES USED :-

import speech_recognition as sr
import webbrowser
import pyttsx3
import pocketsphinx
import requests
import os
import google.generativeai as genai
import subprocess
from songs import play_song, get_random_song
from w import openWebsite, googleSearch
from g import aiProcess
from y import search_youtube, speak
from volume_control import change_volume, mute_volume, unmute_volume, speak
from brightness import set_brightness, speak
from ssr import sleep_system, restart_system, shutdown_system, lock_screen
from srm import check_system_status
from shot import take_screenshot
from Weather import get_weather
from news import get_news
from bulb import control_arduino


#* VOICE RECOGNIZATION SYSTEM :-

recognizer = sr.Recognizer()
engine = pyttsx3.init()

folder_path = r"C:\Users\g k\Music"

voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)  # Select a voice (adjust index as needed)
engine.setProperty('rate', 130)            # Adjust speech rate
engine.setProperty('volume', 1.0)          # Set volume

def speak(text):
    engine.say(text)
    engine.runAndWait()


#* COMMAND FUNCTION :-

def Whatsapp(command):
    return subprocess.Popen(['start', 'whatsapp:'], shell=True)

def Chrome(command):
    return subprocess.Popen(['start', 'Google Chrome:'], shell=True)

def openFileManager():
    subprocess.Popen(["start", "explorer"], shell=True)

def openDrive(drive_letter):
    subprocess.Popen(["start", "explorer", f"{drive_letter}:\\"], shell=True)

def Office(command):
    if "word" in command.lower():
        subprocess.Popen(["start", "winword"], shell=True)
    elif "excel" in command.lower():
        subprocess.Popen(["start", "excel"], shell=True)
    elif "powerpoint" in command.lower():
        subprocess.Popen(["start", "powerpnt"], shell=True)
    elif "outlook" in command.lower():
        subprocess.Popen(["start", "outlook"], shell=True)
    elif "onenote" in command.lower():
        subprocess.Popen(["start", "onenote"], shell=True)


#* COMMAND PROCESSING SYSTEM :-

def processCommand(c):
    print(f"Processing command: {c}")

    if openWebsite(c):
        return True
    
    elif "search google for" in c.lower():
        googleSearch(c)
        return True
    
    
    #? INTEGRATED ARDUINO CONTROL
    
    arduino_response = control_arduino(c)  # Call the Arduino function
    if arduino_response:  # Check if a valid response is received
        speak(arduino_response)
        return True
    


    #? IN-BUILD SOFTWARE BASED COMMANDS :-  

    elif "open whatsapp" in c.lower():
        Whatsapp(c)
        return True

    elif "open chrome" in c.lower():
        Chrome(c)
        return True

    elif "open file manager" in c.lower() or "open explorer" in c.lower():
        openFileManager()
        return True

    elif "open c drive" in c.lower():
        openDrive("C")
        return True

    elif "open d drive" in c.lower():
        openDrive("D")
        return True

    elif "open e drive" in c.lower():
        openDrive("E")
        return True

    elif any(office in c.lower() for office in ["word", "excel", "powerpoint", "outlook", "onenote"]):
        Office(c)
        return True
    

    #? VOLUME CONTROL SYSTEM :-

    elif "increase volume" in c.lower():
        change_volume(0.2)  # Increase by 10%
        return True

    elif "decrease volume" in c.lower():
        change_volume(-0.2)  # Decrease by 10%
        return True

    elif "mute volume" in c.lower():
        mute_volume()
        return True

    elif "unmute volume" in c.lower():
        unmute_volume()
        return True


    #? BRIGHTNESS CONTROL SYSTEM :-
    
    elif "set brightness to" in c.lower():
        try:
            brightness_level = int(c.lower().split("set brightness to")[-1].strip().replace("%", ""))
            set_brightness(brightness_level)
        except ValueError:
            speak("Please specify a valid brightness level.")
        return True
    

    #? DEVICE ON/OFF SYSTEM :-
      
    elif "sleep" in c.lower():
        speak("Putting system to sleep.")
        sleep_system()
        return True

    elif "restart" in c.lower():
        speak("Restarting the system.")
        restart_system()
        return True

    elif "shutdown" in c.lower():
        speak("Shutting down the system.")
        shutdown_system()
        return True
    
    if "lock screen" in command.lower() or "lock my pc" in command.lower():
        speak("Locking the screen.")
        lock_screen()
        return True


    #? SYSTEM RESOURCE MONITORING :-

    elif "system status" in c.lower() or "battery percentage" in c.lower():
        check_system_status()
        return True
    
    
    #? SCREEN-SHOT SYSTEM :-

    if "capture screenshot" in command.lower() or "capture screen" in command.lower():
        take_screenshot()
        return True


    #? RANDOM SONG PLAYER :-  

    elif "songs" in c.lower():
        try:
            file_path = get_random_song(folder_path)
            play_song(file_path)
        except Exception as e:
            print(f"An error occurred: {e}")
        return True
    

    #? USING YouTube API :-

    elif c.lower().startswith("youtube"):
        search_query = c.lower().replace("youtube", "").strip()
        search_youtube(search_query)
        return True
    

    #? USING Weather API :-

    elif "weather in" in c.lower():
        city = c.lower().split("weather in")[-1].strip()
        if city:
            weather_info = get_weather(city)
            print(weather_info)
            speak(weather_info)  
        else:
            speak("Please specify a city.")
        return True
    

    #? USING News API :- 

    if any(keyword in c.lower() for keyword in ["news", "headlines", "latest news"]):
        speak("Fetching the latest news headlines.")
        get_news()  
        return True
    
    
    #? USING Gemini API :-
    elif c:  # Condition corrected here
        output = aiProcess(c)  
        print(f"Gemini Response: {output}")  
        speak(output) 
        return True


#* INITIALIZING MESSAGE :-

if __name__ == "__main__":
    speak("Initializing Meera.......")


#* MICROPHONE & RECOGNIZATION SYSTEM :-

while True:
    try:
        with sr.Microphone() as source:
            print("Meera Active..............")
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=6)

            command = recognizer.recognize_google(audio)
            print(f"Recognized command: {command}")

            keywords = [
                "mira", "meera"
            ]

            if any(keyword in command.lower() for keyword in keywords):
                webbrowser.open("https://www.youtube.com/shorts/MPflYHJc70E")  
            
            else:
                if processCommand(command):  # If a webpage command was executed
                    print("Command accepted!")

    except sr.UnknownValueError:
        speak("Could not understand audio")
    
    except Exception as e:
        speak("An error occurred.")
        print(f"Error: {e}")