import requests
import webbrowser
import pyttsx3

# Initialize text-to-speech engine
engine = pyttsx3.init()

#? YOUTUBE API Key
YOUTUBE_API_KEY = "AIzaSyCtptR_kjOqTl7upUelxnzFBC5gMbTa31E"

def speak(text):
    """Speaks out the given text."""
    engine.say(text)
    engine.runAndWait()

def search_youtube(query):
    """Searches YouTube for a given query and opens the first result."""
    url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&q={query}&type=video&key={YOUTUBE_API_KEY}"
    response = requests.get(url)
    data = response.json()
    
    if 'items' in data and len(data['items']) > 0:
        video_id = data['items'][0]['id']['videoId']
        video_url = f"https://www.youtube.com/watch?v={video_id}"
        webbrowser.open(video_url)
        speak(f"Playing {query} on YouTube")
    else:
        speak("No results found on YouTube.")
