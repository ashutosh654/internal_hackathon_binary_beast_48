import serial
import time

#* ARDUINO SETUP (Change COM Port as needed)
try:
    arduino = serial.Serial(port='COM4', baudrate=9600, timeout=1)
    time.sleep(2)  # Wait for Arduino to initialize
    print("✅ Arduino connected successfully.")
    arduino.write("5".encode())  # Automatically start blinking LEDs
    time.sleep(0.1)
except Exception as e:
    print(f"⚠️ Arduino connection error: {e}")
    arduino = None  # If no connection, set to None

def control_arduino(command):
    """Controls the LED, Fan, and Blinking LEDs via Arduino."""
    if arduino is None:
        return "Arduino is not connected."

    command_dict = {
        "turn on the led": "1",
        "turn off the led": "0",
        "turn on fan": "3",
        "turn off fan": "2",
        "start blinking the leds": "5",
        "stop blinking the leds": "5"
    }

    for key, value in command_dict.items():
        if key in command.lower():
            arduino.write(value.encode())  # Send command to Arduino
            time.sleep(0.1)
            response = arduino.readline().decode().strip()  # Read response
            return f"Arduino says: {response}" if response else "Command sent successfully."

    return "Invalid command for Arduino."

if __name__ == "__main__":
    print("Arduino control module ready.")
