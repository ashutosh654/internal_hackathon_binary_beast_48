import requests

# API Key (Consider storing this securely)
news_api = "0f27180d68c24936aa85aa07fc23b071"

def get_news():
    url = f"https://newsapi.org/v2/top-headlines?country=in&apiKey={news_api}"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        articles = data.get('articles', [])

        if articles:
            for article in articles:
                print(article['title']) 
        else:
            print("No news articles found.")
    else:
        print(f"Error fetching news: {response.status_code}")

# Example usage:
get_news()
