from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
from comtypes import CLSCTX_INPROC_SERVER
import pyttsx3


# Initialize text-to-speech engine
engine = pyttsx3.init()

def speak(text):
    """Speaks out the given text."""
    engine.say(text)
    engine.runAndWait()

def change_volume(change):
    """Increases or decreases the system volume."""
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_INPROC_SERVER, None)
    volume = interface.QueryInterface(IAudioEndpointVolume)
    
    current_volume = volume.GetMasterVolumeLevelScalar()
    new_volume = max(0.0, min(1.0, current_volume + change))  # Keep volume between 0.0 and 1.0
    volume.SetMasterVolumeLevelScalar(new_volume, None)

    if change > 0:
        speak("Volume increased")
    else:
        speak("Volume decreased")

def mute_volume():
    """Mutes the system volume."""
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_INPROC_SERVER, None)
    volume = interface.QueryInterface(IAudioEndpointVolume)
    
    volume.SetMute(1, None)
    speak("Volume muted")

def unmute_volume():
    """Unmutes the system volume."""
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_INPROC_SERVER, None)
    volume = interface.QueryInterface(IAudioEndpointVolume)
    
    volume.SetMute(0, None)
    speak("Volume unmuted")
