import requests

API_KEY = "58d34af9f72f25112d2b06d5b22061cf"  # Paste your real API key
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

def get_weather(city):
    params = {"q": city, "appid": API_KEY, "units": "metric"}
    response = requests.get(BASE_URL, params=params)
    data = response.json()

    if data.get("cod") == 200:
        return f"Weather in {city}: {data['weather'][0]['description']}, {data['main']['temp']}°C"
    else:
        return f"API Error: {data.get('message', 'Unknown error')}"
