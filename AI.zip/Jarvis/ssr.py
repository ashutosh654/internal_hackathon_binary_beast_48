import os

def sleep_system():
    os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")  # Sleep Mode

def restart_system():
    os.system("shutdown /r /t 1")  # Restart System

def shutdown_system():
    os.system("shutdown /s /t 1")  # Shutdown System

def lock_screen():
    os.system("rundll32.exe user32.dll,LockWorkStation")  # lock screen

def processCommand(c):
    print(f"Processing command: {c}")